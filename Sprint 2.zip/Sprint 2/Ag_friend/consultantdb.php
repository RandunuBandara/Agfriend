<?php 

$dbServername="localhost";
$dbusername="root";
$dbPassword="Thushan5483";
$dbServername="user_registration";


$conn= mysqli_connect($dbServername,$dbusername,$dbPassword)


?>