<?php 

$dbServername="localhost";
$dbUsername="root";
$dbPassword="Thushan5483";
$dbName="user_registration";


$conn= mysqli_connect($dbServername,$dbUsername,$dbPassword,$dbName);


?>