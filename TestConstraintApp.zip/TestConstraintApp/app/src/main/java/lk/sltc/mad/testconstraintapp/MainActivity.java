package lk.sltc.mad.testconstraintapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Button;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;

    List<Car> cars = new ArrayList<Car>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list);

        Button btn = findViewById(R.id.button);

        recyclerView = findViewById(R.id.rv_list);

        recyclerView.setHasFixedSize(true);

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        populateCars();

        CarListAdapter adapter = new CarListAdapter(this.cars);
        recyclerView.setAdapter(adapter);
    }

    private void populateCars() {
        Car car1 = new Car("BMW", "2020", "Navy Blue");
        cars.add(car1);
        Car car2 = new Car("Mazda", "2019", "Aqua White");
        cars.add(car2);
        Car car3 = new Car("Benz", "2018", "Pearl White");
        cars.add(car3);
        Car car4 = new Car("Toyota", "2020", "Red");
        cars.add(car4);
    }
}