package lk.sltc.mad.testconstraintapp;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class CarItemViewHolder extends RecyclerView.ViewHolder {

    TextView titleView;
    TextView descriptionView;

    public CarItemViewHolder(@NonNull View itemView) {
        super(itemView);

        titleView = itemView.findViewById(R.id.tv_car_title);
        descriptionView = itemView.findViewById(R.id.tv_car_description);
    }
}
