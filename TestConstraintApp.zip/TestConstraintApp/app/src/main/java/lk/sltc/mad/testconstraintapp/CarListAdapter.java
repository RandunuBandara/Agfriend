package lk.sltc.mad.testconstraintapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class CarListAdapter extends RecyclerView.Adapter {

    List<Car> cars;

    public CarListAdapter(List<Car> cars) {
        this.cars = cars;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View itemView = inflater.inflate(R.layout.car_item_layout, parent, false);
        CarItemViewHolder viewHolder = new CarItemViewHolder(itemView);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        CarItemViewHolder itemViewHolder = (CarItemViewHolder)holder;

        Car carItem = cars.get(position);

        itemViewHolder.titleView.setText(carItem.getModel());
        itemViewHolder.descriptionView.setText(carItem.getYear() + " - color: " + carItem.getColor());
    }

    @Override
    public int getItemCount() {
        return cars.size();
    }
}
